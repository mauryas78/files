import base64
import json
import logging
import time
import os, fnmatch

# 3rd party imports
import psycopg2 
import subprocess
from azure.servicebus import ServiceBusClient

from languageops import *
# from connpool import getDBConnection, putDBConnection
# from dbengine import *


# # logger Configuration
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)
# formatter = logging.Formatter('%(message)s')

# # import language settings
# with open('langs_config.json') as f:
#     langs_config = json.load(f)

# def add_logger(timestamp, level, msg):
#     # connection = getDBConnection()  

#     obj = {
#         'timestamp': timestamp,
#         'level': level,
#         'msg': msg
#     }

#     db_insert_worker1_log(level=obj['level'],message= obj['msg'])

# class GeneralHandler(logging.Handler):
#     """
#     Logging Handler for all logs
#     """
#     def emit(self, record):
#         timestamp = str(time.strftime("%Y-%m-%d %H:%M:%S%z"))
#         log_entry = self.format(record)
#         level = record.levelname
#         add_logger(timestamp, level, str(log_entry))


# Log Handler Configuration
generalHandler = GeneralHandler()
generalHandler.setFormatter(formatter)
generalHandler.setLevel(logging.DEBUG)
logger.addHandler(generalHandler)

def find_worker(pattern, box):
    """returns a list of testcase input file locations """
    result = []
    # print(path)
    path = "/var/local/lib/isolate/" + str(box) + "/box/"
    for root, dirs, files in os.walk(path):
        for name in files:
            # print(name)
            if fnmatch.fnmatch(name, pattern):
                result.append(name)
    return result

def read_meta(file_name):
    """
    Function to read meta data of the program such as execution time, memory, etc

    Parameters:
        fileName(str): Name of file which contains meta data of program

    Returns:
        dict: Dictionary which contains all metadata
    """
    meta = {}
    with open(file_name) as myfile:
        for line in myfile:
            name, var = line.partition(":")[::2]
            meta[name.strip()] = str(var).rstrip()

    return meta


# read the compilation error in sandbox
def read_compilation_error(box_id, list_of_testcase_input):
    print(list_of_testcase_input)
    error_info = ''
    with open("/var/local/lib/isolate/" + str(box_id) + "/box/error.txt", "r") as fs:
        error_info = fs.read()
        if len(error_info) >= 1000:
            # if output is too long it is truncated
            error_info = error_info[:1000]
            error_info = error_info + '...(output truncated)'

        return error_info


# formatted data for successful compilation
def formatted_output(box_id, list_of_testcase_input):
    list_of_input_files = find_worker('input_*.txt', box_id)
    output_dict = {'input': '', 'output': ''}
    output = []
    try:
        for i in range(len(list_of_input_files)):
            with open("/var/local/lib/isolate/" + str(box_id) + "/box/input_{}.txt".format(i), "r") as fs:
                with open("/var/local/lib/isolate/" + str(box_id) + "/box/output_{}.txt".format(i), "r") as f:
                    meta = read_meta("/var/local/lib/isolate/" + str(box_id) + "/box/meta_{}.txt".format(i))
                    with open("/var/local/lib/isolate/" + str(box_id) + "/box/error_{}.txt".format(i), "r") as fd:
                        input_data = fs.read()
                        output_data = f.read().replace("\x00", "")    # NULL value replace with ""
                        error_data = fd.read().replace("\x00", "")   # NULL value replace with ""
                        
                        if len(output_data) >= 1000:
                            # if output is too long it is truncated
                            output_data = output_data[:1000]
                            output_data = output_data + '...(output truncated)'
                        output_dict['input'] = input_data  
                        output_dict['output'] = output_data 
                        output_dict['memory'] = 00.00
                        output_dict['exctime'] = meta['time']
                        output_dict['error'] = error_data

                        exitcode = meta.get('exitcode', None)
                        if exitcode == '0':
                            meta['status'] = 'OK'
                            meta['message'] = 'compilation successful'
                        elif meta['status'] == 'TLE' or meta['status'] == 'RE' or meta['status'] == 'SG' or meta[
                            'status'] == 'XX':
                            meta["cg-mem"] = 00.00
read_meta
                        output_dict['status'] = meta['status']
                        output_dict['message'] = meta['message']
                        output.append(output_dict.copy())
    except Exception as e:
        logger.exception("getting error  while generating output {}".format(e))

    for i in range(len(list_of_testcase_input)):
        for j in range(len(output)):
            if i == j:
                output[j]['testcaseid'] = list_of_testcase_input[i]['testcaseid']

    return output


# update the database
# def update_database(submission, status, meta):
#     """
#     updates the verdict to database

#     Parameters:
#         submission(int): unique ID of the submission
#         status(str): verdict of the submission
#         meta(dict): collection of all the results
#     """
#     if status == 'OK':
#         try:
#             for i in meta['output']:
#                 if "\x00" in i["output"]: 
#                     i["output"] = "NULL"
                    
#                 i["output"].replace("\x00", "\uFFFD")

#                 db_update_submission_testcase_status(i['output'], i['memory'], i['exctime'], i['status'], i['error'], i['testcaseid'])

#             db_update_submission_status(error_message ="", status=status,submission_id=submission)  
            
#         except Exception as e:
#             logger.error(" Error {} while storing output for submission {}".format(e, submission))

#     if status  == "CTE" or status  == "TO" :
#         db_update_submission_status(error_message = meta['error_message'], status =status, submission_id = submission)
#         db_update_submission_testcase_status_cte( status=status, error = meta['error_message'], sub_id = submission)
#     if status == 'DOJ':
#         # Denial of judgement, in case any error occurs such that worker is unable to judge the submission
#         data = 'Denial Of Judgement'
#         db_update_submission_status(error_message = str(data), status =status, submission_id = submission)

def isolate_initiate(box_id, input_data, code, lang):
    """
    initialize the isolate sandbox

    Parameters:
        box_id(int): isolate box ID for the submission
        input_data(list): input Data for the submission and testcase id
        code(str): Main file for the submission
        lang(str): language for the submission
    """

    print('Call isolate_initiate')

    # initialize box for isolate module
    subprocess.call("isolate --cleanup -b " + str(box_id), shell=True)
    # subprocess.call("isolate --cg --init -d rw -b " + str(box_id), shell=True)
    subprocess.call("isolate --init -d rw -b " + str(box_id), shell=True)

    # subprocess.call("gcc --version", shell=True)

    # Write input file (input to the code)
    count = 0
    for item in input_data:
        if count<(len(input_data)):
            with open("/var/local/lib/isolate/" + str(box_id) + "/box/input_{}.txt".format(count), "w+") as f_input:
                f_input.write(item['input']+'\n')
                count +=1

    # Write output file( write the code in associated file)
    f_code = open("/var/local/lib/isolate/" + str(box_id) + "/box/" +langs_config[lang]['inputFile'], "w+")
    f_code.write(code)

    f_code.close()

def callback(body):
    """Main function which is called back by RabbitMQ"""
    print('The message body is ', body)

    try:
        output = {}

        list_of_testcases_inputs = []
        submission = int(body)
        box_id = submission % 1000

        try:
            row = db_get_submission_testcase_details(sub_id=submission)
            logger.info("funtion db submission testcase executed ")
            print(row)
            code = row[0][0]
            language = row[0][2]                        
            print(language)
            temp_dict_of_testcase_and_input = {}

            for item in row:
                temp_dict_of_testcase_and_input['testcaseid'] = item[3]
                temp_dict_of_testcase_and_input['input'] = item[1]
                list_of_testcases_inputs.append(temp_dict_of_testcase_and_input.copy())            
            row = db_get_language_config_details(language)
            print(row)
            config = {
                'dir': row[1],
                'stack_limit': row[2],
                'mem_limit': row[3],
                'filesize_limit': row[4],
                'process_limit': row[5],
                'time_limit': row[6],
                'wall_time_limit': row[7],
                'allowed_ips': row[8]
            }

        except Exception as e:
            # logger.exception("Error {} in submission {} ".format(e, submission))
            return

        # Initialize the submission
        isolate_initiate(box_id, list_of_testcases_inputs, code, language)

        # Define compile code and run code acc to language
        if language == 'cpp':
            # C++
            compile_code = getattr(cpp, 'compile')
            run_code = getattr(cpp, 'run')
        if language == 'c':
            # C
            compile_code = getattr(c, 'compile')
            run_code = getattr(c, 'run')
        if language == 'py2':
            # Python2
            compile_code = getattr(py2, 'compile')
            run_code = getattr(py2, 'run')
        if language == 'py3':
            # Python3
            compile_code = getattr(py3, 'compile')
            run_code = getattr(py3, 'run')
        if language == 'java8':
            # Java 8
            compile_code = getattr(java8, 'compile')
            run_code = getattr(java8, 'run')
        if language == 'cs':
            # C# (C Sharp)
            compile_code = getattr(cs, 'compile')
            run_code = getattr(cs, 'run')
        if language == 'nodejs':
            # Node JS
            compile_code = getattr(nodejs, 'compile')
            run_code = getattr(nodejs, 'run')
        if language == 'js':
            try:
                compile_code = getattr(js, 'compile')
                run_code = getattr(js, 'run')
            except Exception as e:
                logger.exception("exception in js {}".format(e))
        if language == 'ts':
            # typescript
            try:
                compile_code = getattr(ts, 'compile')
                run_code = getattr(ts, 'run')
            except Exception as e:
                logger.exception("exception in ts {}".format(e))
        if language == 'php':
            # PHP
            compile_code = getattr(php, 'compile')
            run_code = getattr(php, 'run')
        if language == 'bash':
            # Bash
            print("inside bash")
            compile_code = getattr(bash, 'compile')
            run_code = getattr(bash, 'run')

        if language == 'go':
            # Go
            compile_code = getattr(go, 'compile')
            run_code = getattr(go, 'run')
        if language == 'ruby':
            # Ruby
            compile_code = getattr(Ruby, 'compile')
            run_code = getattr(Ruby, 'run')
        if language == 'swift':
            # Swift
            compile_code = getattr(Swift, 'compile')
            run_code = getattr(Swift, 'run')
        if language == 'objc':
            # Objective C
            compile_code = getattr(ObjC, 'compile')
            run_code = getattr(ObjC, 'run')
        if language == 'perl':
            # Perl
            compile_code = getattr(Perl, 'compile')
            run_code = getattr(Perl, 'run')
        if language == 'sqlite':
            # SQLite
            compile_code = getattr(Sqlite, 'compile')
            run_code = getattr(Sqlite, 'run')
        if language == 'scala':
            # Scala
            compile_code = getattr(Scala, 'compile')
            run_code = getattr(Scala, 'run')
        if language == 'r':
            # R
            compile_code = getattr(R, 'compile')
            run_code = getattr(R, 'run')
            
        if language == 'dart':
            # dart
            compile_code = getattr(dart, 'compile')
            run_code = getattr(dart, 'run')   

        if language == 'kotlin':
            # kotlin
            compile_code = getattr(Kotlin, 'compile')
            run_code = getattr(Kotlin, 'run')
        
        if language == 'rust':
            # rust
            logger.info("get rust attr")
            compile_code = getattr(rust, 'compile')
            run_code = getattr(rust, 'run')
        
        if language == 'lua':
           # lua
           compile_code = getattr(lua, 'compile')
           run_code = getattr(lua, 'run')

        if language == 'groovy':
           # groovy 
           compile_code = getattr(groovy, 'compile')
           run_code = getattr(groovy, 'run')

        is_compile = compile_code(box_id)

        # Check for Compile time error
        if not is_compile:
            try:
                status = 'CTE'

                error = read_compilation_error(box_id, list_of_testcases_inputs)
               
                output['status'] = status
                output['error_message'] = error
                update_database(submission, status, output)
                # logger.info("Code compiled Successfully for {}".format(submission))
            except Exception as e:
                # print("Exception CTE ", e)
                # logger.exception("Error {} While compiling the code for {}".format(e, submission))
        else:

            run_code(box_id, config)
            os.system("cd /var/local/lib/isolate/" + str(box_id) + "/box/  && ls -a  ")
            output["box_id"] = box_id
            output['submission_id'] = submission
            status = 'OK'
            out = formatted_output(box_id, list_of_testcases_inputs)
            output['output'] = out
            
            update_database(submission, status, output)
            subprocess.call("isolate --cleanup -b " + str(box_id), shell=True)

    except Exception as e:
        submission = int(body)
        # logger.error("getting error {} and doj message for {}".format(e, submission))
        update_database(submission, 'DOJ', {})

connstr = str(os.getenv("ASB_CONNECTIONSTRING"))
queue_name = os.getenv('MOC_QUEUE_1_NAME')

with ServiceBusClient.from_connection_string(connstr) as client:   
    with client.get_queue_receiver(queue_name=queue_name) as receiver:
        for msg in receiver:
            print(str(msg))
            callback(str(msg))
            receiver.complete_message(msg)

import redis

class RedisClient:
    def __init__(self, 
                 host='localhost', 
                 port=6379, 
                 db=0,
                 user="",
                 password=""):
        
        creds_provider = redis.UsernamePasswordCredentialProvider("", "cajbT4MYNtJeqn8dpZxmNUQXtmOLrue5UAzCaBTt2Rk=")

        self.redis_pool = redis.ConnectionPool(
            host="redismocdb-t-eus-redis.redis.cache.windows.net", 
            port=6380, 
            db=db,
            credential_provider=creds_provider,
            max_connections=10,
            connection_class=redis.SSLConnection,
            ssl_cert_reqs= 'none',
        )


    def get_redis_connection(self):
        """Get a Redis connection from the pool."""
        return redis.Redis(connection_pool=self.redis_pool)

    def get_value(self, key):
        """Retrieves a value from Redis."""
        redis_client = self.get_redis_connection()
        value = redis_client.get(key)
        if value:
            return value.decode('utf-8')
        else:
            return None

    def set_value(self, key, value):
        """Sets a key-value pair in Redis."""
        redis_client = self.get_redis_connection()
        redis_client.set(key, value)

    def update_value(self, key, new_value):
        """Updates an existing value in Redis."""
        redis_client = self.get_redis_connection()
        redis_client.set(key, new_value)
import json
import os.path
import subprocess

"""
This file has language specific execution code.
For each language, there is a class which has two function - 'compile' and 'run'
    => compile function : this function will compile the code and return True if compilation
                       is successful.
    => run function: this function will execute the code in isolate sandbox
"""
# import language settings
# with open('langs_config.json') as f:
#     langs_config = json.load(f)

# find input files
import os, fnmatch


def find(pattern, box):
    result = []
    # print(path)
    path = "/var/local/lib/isolate/" + str(box) + "/box/"
    for root, dirs, files in os.walk(path):
        for name in files:
            # print(name)
            if fnmatch.fnmatch(name, pattern):
                result.append(name)
    return result


# C++
class cpp:
    def compile(box_id):
        subprocess.call("cd /var/local/lib/isolate/" + str(
            box_id) + '/box;' + "g++ ./" + langs_config['cpp']['inputFile'] + " -O2 --std=c++17 -o " +
                        langs_config['cpp']['outputFile'] + " 2> error.txt",
                        shell=True)
        if not (os.path.exists('/var/local/lib/isolate/' + str(box_id) + '/box/' + langs_config['cpp']['outputFile'])):
            return False
        return True

    def run(box_id, config):
        # print(config['time_limit'], flush=True)
        no_of_input_files = find('input_*.txt', box_id)
        for input in range(len(no_of_input_files)):
            subprocess.call("isolate --run -p  -s --mem=" + str(config['mem_limit']) +
                            " --time=" + str(config['time_limit']) +
                            " --wall-time=" + str(config['wall_time_limit']) +
                            " -b " + str(box_id) +
                            " -o output_{}.txt -i input_{}.txt -M /var/local/lib/isolate/".format(input, input) + str(
                box_id) + "/box/meta_{}.txt -r error_{}.txt ./".format(input, input) +
                            langs_config['cpp']['outputFile'],
                            shell=True)

# C
class c:
    def compile(box_id):
        subprocess.call("cd /var/local/lib/isolate/" + str(
            box_id) + '/box;' + "gcc ./" + langs_config['c']['inputFile'] + " -O2 -o " + langs_config['c'][
                            'outputFile'] + " 2> error.txt",
                        shell=True)
        if not (os.path.exists('/var/local/lib/isolate/' + str(box_id) + '/box/' + langs_config['c']['outputFile'])):
            return False
        return True

    def run(box_id, config):
        print("time limit for c", str(config['time_limit']))
        no_of_input_files = find('input_*.txt', box_id)
        for input in range(len(no_of_input_files)):
            subprocess.call("isolate --run -p  -s --mem=" + str(config['mem_limit']) +
                            " --time=" + str(config['time_limit']) +
                            " --wall-time=" + str(config['wall_time_limit']) +
                            " -b " + str(box_id) +
                            " -o output_{}.txt -i input_{}.txt -M /var/local/lib/isolate/".format(input, input) + str(
                box_id) + "/box/meta_{}.txt -r error_{}.txt ./".format(input, input) +
                            langs_config['c']['outputFile'],
                            shell=True)

# Python3
class py3:
    def compile(box_id):
        return True

    def run(box_id):
        try:
            no_of_input_files = find('input_*.txt', box_id)
            for input in range(len(no_of_input_files)):
                subprocess.call("isolate --run -p -s --mem=256000 -t 2 -w 3 -b " + str(box_id) +
                                " --share-net --full-env  --env=HOME=/home/user" +
                                " -o output_{}.txt -i input_{}.txt -M /var/local/lib/isolate/".format(input,
                                                                                                      input) + str(
                    box_id) + "/box/meta_{}.txt -r error_{}.txt".format(input, input) +
                                " /usr/bin/python3 main.py",
                                shell=True)
        except Exception as e:
            print("in run error")
            print(e)


# # Python2
# class py2:
#     def compile(box_id):
#         return True

#     def run(box_id, config):
#         no_of_input_files = find('input_*.txt', box_id)
#         for input in range(len(no_of_input_files)):
#             subprocess.call("isolate --run -p -s --mem=" + str(config['mem_limit']) +
#                             " -t " + str(config['time_limit']) +
#                             " -w " + str(config['wall_time_limit']) +
#                             " -b " + str(box_id) +
#                             " --share-net --full-env  --env=HOME=/home/user " +
#                             "-o output_{}.txt -i input_{}.txt -M /var/local/lib/isolate/".format(input, input) + str(
#                 box_id) + "/box/meta_{}.txt -r error_{}.txt".format(input, input) +
#                             " /usr/bin/python2 " + langs_config['py2']['outputFile'],
#                             shell=True)


# C# (C-sharp)
class cs:
    def compile(box_id):
        subprocess.call("cd /var/local/lib/isolate/" + str(
            box_id) + '/box;' + "mcs ./" + langs_config['cs']['inputFile'] + " -out:" + langs_config['cs'][
                            'outputFile'] + " 2> error.txt",
                        shell=True)
        if not (os.path.exists('/var/local/lib/isolate/' + str(box_id) + '/box/' + langs_config['cs']['outputFile'])):
            return False
        return True

    def run(box_id, config):
        no_of_input_files = find('input_*.txt', box_id)
        for input in range(len(no_of_input_files)):
            subprocess.call("isolate -p --run -s --mem=" + str(config['mem_limit']) +
                            " -t " + str(config['time_limit']) +
                            " -w " + str(config['wall_time_limit']) +
                            " -b " + str(box_id) +
                            " --share-net --full-env  --dir=/etc/=/etc/ --dir=/usr/lib/=/usr/lib/  --env=HOME=/home/mocha " +
                            " -o output_{}.txt -i input_{}.txt -M /var/local/lib/isolate/".format(input, input) + str(
                box_id) + "/box/meta_{}.txt -r error_{}.txt ".format(input, input) +
                            "/usr/bin/mono " + langs_config['cs']['outputFile'],
                            shell=True)


# Java 8
class java8:
    def compile(box_id):
        subprocess.call("cd /var/local/lib/isolate/" + str(
            box_id) + '/box;' + "javac ./" + langs_config['java8']['inputFile'] + " 2> error.txt",
                        shell=True)
        if not (
        os.path.exists('/var/local/lib/isolate/' + str(box_id) + '/box/' + langs_config['java8']['outputFile'])):
            # If error file is empty but Main.class does not exist, main class name is not "Main"
            err_file = open('/var/local/lib/isolate/' + str(box_id) + '/box/error.txt', 'r+')

            if err_file.read() == "":
                err_file.write(
                    'Please use the main class name as "Main" only.')

            err_file.close()
            return False
        return True

    def run(box_id, config):
        no_of_input_files = find('input_*.txt', box_id)
        for input in range(len(no_of_input_files)):
            subprocess.call("isolate --run -p  " +
                            " --time=" + str(config['time_limit']) +
                            " --wall-time=" + str(config['wall_time_limit']) +
                            " -b " + str(box_id) +
                            " --share-net --full-env   --env=HOME=/home/mocha " +
                            " -o output_{}.txt -i input_{}.txt -M /var/local/lib/isolate/".format(input, input) + str(
                box_id) + "/box/meta_{}.txt -r error_{}.txt".format(input, input) +
                            " /usr/lib/jvm/java-8-openjdk-amd64/bin/java Main",
                            shell=True)

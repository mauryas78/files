import base64
import json
import logging
import time
import os, fnmatch,load_dotenv

# 3rd party imports
import psycopg2 
import subprocess
from azure.servicebus import ServiceBusClient

from languageops import *
# from connpool import getDBConnection, putDBConnection
from redis_cache_engine import *


import os
from dotenv import load_dotenv

load_dotenv()

# Retrieve and print the ASB_CONNECTIONSTRING value
# # logger Configuration
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)
# formatter = logging.Formatter('%(message)s')

# import language settings
# with open('langs_config.json') as f:
#     langs_config = json.load(f)

# def add_logger(timestamp, level, msg):
    # connection = getDBConnection()  

#     obj = {
#         'timestamp': timestamp,
#         'level': level,
#         'msg': msg
#     }

#     db_insert_worker1_log(level=obj['level'],message= obj['msg'])

# class GeneralHandler(logging.Handler):
#     """
#     Logging Handler for all logs
#     """
#     def emit(self, record):
#         timestamp = str(time.strftime("%Y-%m-%d %H:%M:%S%z"))
#         log_entry = self.format(record)
#         level = record.levelname
#         add_logger(timestamp, level, str(log_entry))


# # Log Handler Configuration
# generalHandler = GeneralHandler()
# generalHandler.setFormatter(formatter)
# generalHandler.setLevel(logging.DEBUG)
# logger.addHandler(generalHandler)

def find_worker(pattern, box):
    result = []
    # print(path)
    path = "/var/local/lib/isolate/" + str(box) + "/box/"
    for root, dirs, files in os.walk(path):
        for name in files:
            # print(name)
            if fnmatch.fnmatch(name, pattern):
                result.append(name)
    return result

def read_meta(file_name):
    """
    Function to read meta data of the program such as execution time, memory, etc

    Parameters:
        fileName(str): Name of file which contains meta data of program

    Returns:
        dict: Dictionary which contains all metadata
    """
    meta = {}
    with open(file_name) as myfile:
        for line in myfile:
            name, var = line.partition(":")[::2]
            meta[name.strip()] = str(var).rstrip()

    return meta


# read the compilation error in sandbox
def read_compilation_error(box_id, list_of_testcase_input):
    print(list_of_testcase_input)
    error_info = ''
    with open("/var/local/lib/isolate/" + str(box_id) + "/box/error.txt", "r") as fs:
        error_info = fs.read()
        if len(error_info) >= 1000:
            # if output is too long it is truncated
            error_info = error_info[:1000]
            error_info = error_info + '...(output truncated)'

        return error_info


# formatted data for successful compilation
def formatted_output(box_id, list_of_testcase_input):
    list_of_input_files = find_worker('input_*.txt', box_id)
    output_dict = {'input': '', 'output': ''}
    output = []
    try:
        for i in range(len(list_of_input_files)):
            with open("/var/local/lib/isolate/" + str(box_id) + "/box/input_{}.txt".format(i), "r") as fs:
                with open("/var/local/lib/isolate/" + str(box_id) + "/box/output_{}.txt".format(i), "r") as f:
                    meta = read_meta("/var/local/lib/isolate/" + str(box_id) + "/box/meta_{}.txt".format(i))
                    print(meta)
                    with open("/var/local/lib/isolate/" + str(box_id) + "/box/error_{}.txt".format(i), "r") as fd:
                        input_data = fs.read()
                        output_data = f.read().replace("\x00", "")    # NULL value replace with ""
                        error_data = fd.read().replace("\x00", "")   # NULL value replace with ""
                        
                        if len(output_data) >= 1000:
                            # if output is too long it is truncated
                            output_data = output_data[:1000]
                            output_data = output_data + '...(output truncated)'
                        output_dict['input'] = input_data  
                        output_dict['output'] = output_data 
                        output_dict['memory'] = 00.00
                        output_dict['exctime'] = meta['time']
                        output_dict['error'] = error_data

                        exitcode = meta.get('exitcode', None)
                        if exitcode == '0':
                            meta['status'] = 'OK'
                            meta['message'] = 'compilation successful'
                        elif meta['status'] == 'TLE' or meta['status'] == 'RE' or meta['status'] == 'SG' or meta[
                            'status'] == 'XX':
                            meta["cg-mem"] = 00.00

                        output_dict['status'] = meta['status']
                        output_dict['message'] = meta['message']
                        output.append(output_dict.copy())
    except Exception as e:
        # logger.exception("getting error  while generating output {}".format(e))

        for i in range(len(list_of_testcase_input)):
            for j in range(len(output)):
                if i == j:
                    output[j]['testcaseid'] = list_of_testcase_input[i]['testcaseid']

    return output


# update the database
# def update_database(submission, status, meta):
#     """
#     updates the verdict to database

#     Parameters:
#         submission(int): unique ID of the submission
#         status(str): verdict of the submission
#         meta(dict): collection of all the results
#     """
#     if status == 'OK':
#         try:
#             for i in meta['output']:
#                 if "\x00" in i["output"]: 
#                     i["output"] = "NULL"
                    
#                 i["output"].replace("\x00", "\uFFFD")

#                 db_update_submission_testcase_status(i['output'], i['memory'], i['exctime'], i['status'], i['error'], i['testcaseid'])

#             db_update_submission_status(error_message ="", status=status,submission_id=submission)  
            
#         except Exception as e:
#             logger.error(" Error {} while storing output for submission {}".format(e, submission))

#     if status  == "CTE" or status  == "TO" :
#         db_update_submission_status(error_message = meta['error_message'], status =status, submission_id = submission)
#         db_update_submission_testcase_status_cte( status=status, error = meta['error_message'], sub_id = submission)
#     if status == 'DOJ':
#         # Denial of judgement, in case any error occurs such that worker is unable to judge the submission
#         data = 'Denial Of Judgement'
#         db_update_submission_status(error_message = str(data), status =status, submission_id = submission)

def isolate_initiate(box_id, input_data, code, lang_file_name):
    """
    initialize the isolate sandbox

    Parameters:
        box_id(int): isolate box ID for the submission
        input_data(list): input Data for the submission and testcase id
        code(str): Main file for the submission
        lang(str): language for the submission
    """
    print('Call isolate_initiate')

    # initialize box for isolate module
    subprocess.call("isolate --cleanup -b " + str(box_id), shell=True)
    # subprocess.call("isolate --cg --init -d rw -b " + str(box_id), shell=True)
    subprocess.call("isolate --init -d rw -b " + str(box_id), shell=True)
    # subprocess.call("gcc --version", shell=True)

    # Write input file (input to the code)
    count = 0
    for item in input_data:
        if count<(len(input_data)):
            with open("/var/local/lib/isolate/" + str(box_id) + "/box/input_{}.txt".format(count), "w+") as f_input:
                f_input.write(item['input']+'\n')
                count +=1
    # Write output file( write the code in associated file)
    # subprocess.call("touch /var/local/lib/isolate/" + str(box_id) + "/box/main.py", shell=True)
    # f_code = open("/var/local/lib/isolate/" + str(box_id) + "/box/main.py"," w+")
    # f_code.write(code)
    input_file_path = f"/var/local/lib/isolate/{box_id}/box/{lang_file_name}"
    # Open the file in write-plus mode and write to it
    with open(input_file_path, "w+") as f_code:
        f_code.write(code)
    f_code.close()

def callback(body):
    """Main function which is called back by RabbitMQ"""
    print('The message body is ', body)

    try:
        

        list_of_testcases_inputs = []
        submissionid = int(body)
        box_id = submissionid % 1000

        try:
            client_redis=RedisClient()
            submission_data_str=client_redis.get_value(submissionid)
            submission_data=json.loads(submission_data_str)
            print(submission_data)

        except Exception as e:
            print("Error {} in submission {} ".format(e, submissionid))
            return

        language_map={
            'py3': {'compile': getattr(py3, 'compile'), 'run': getattr(py3, 'run'), 'mainfile':'main.py'}
            }
        
        if submission_data['language'] in list(language_map.keys()):

            isolate_initiate(box_id, submission_data['input'], submission_data['code'],language_map[submission_data['language']]['mainfile'])

            compile_code = language_map[submission_data['language']]['compile']

            run_code = language_map[submission_data['language']]['run']

        else:
            print("language not supported")

        is_compile = compile_code(box_id)

        # Check for Compile time error
        if not is_compile:
            try:
                status = 'CTE'

                error = read_compilation_error(box_id, list_of_testcases_inputs)
                
                submission_data['status'] = status
                submission_data['error_message'] = error

                client_redis.update_value(submissionid,new_value=json.dumps(submission_data))
                # logger.info("Code compiled Successfully for {}".format(submission))
            except Exception as e:
                
                print("Exception CTE ", e)
                # logger.exception("Error {} While compiling the code for {}".format(e, submission))
        else:
            run_code(box_id)
            os.system("cd /var/local/lib/isolate/" + str(box_id) + "/box/  && ls -a  ")
            # output["box_id"] = box_id
            # output['submission_id'] = submission
            out = formatted_output(box_id, submission_data['input'])
            print(out)
            # submission_data.pop('input')
            submission_data['output'] = out
            submission_data['status'] = out[0]['status']
            client_redis.update_value(submissionid,new_value=json.dumps(submission_data))
            # update_database(submission, status, output)
            # subprocess.call("isolate --cleanup -b " + str(box_id), shell=True)

    except Exception as e:
        submissionid = int(body)
        # logger.error("getting error {} and doj message for {}".format(e, submission))
        # update_database(submission, 'DOJ', {})

connstr = str(os.getenv("ASB_CONNECTIONSTRING"))
queue_name = os.getenv('MOC_QUEUE_1_NAME')

with ServiceBusClient.from_connection_string(connstr) as client:   
    with client.get_queue_receiver(queue_name=queue_name) as receiver:
        for msg in receiver:
            print(str(msg))
            callback(str(msg))
            receiver.complete_message(msg)
